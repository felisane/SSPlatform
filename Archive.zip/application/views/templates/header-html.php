<!DOCTYPE html>
<html>
<head>
	<title>SSPlatform - Bem Vindo</title>
	<meta charset="UTF-8">
	<meta lang="pt-br">
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<!--Ficheiro responsável elos icons-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/resources/vendors/css/ionicons.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body>