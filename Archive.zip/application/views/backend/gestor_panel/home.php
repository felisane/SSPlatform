<header class="main-header">
	<nav class="navegacao-principal">
		<div class="row">
			<div class="logo-div">
				<img src="<?php echo base_url(); ?>assets/imagens/logo.png" alt="logotipo">
				<form>
					<input type="search">
				</form>
			</div>
			<div class="nav-direita">
				<img src="<?php echo base_url(); ?>assets/imagens/usuario.png">	<span class="nome_do_usuario"><?php echo $user_db->first_name; ?></span>	
				<!--Menú da versão mobile-->	
				<a class="mobile-nav js--mobile-nav"><i class="ion-navicon-round"></i></a>
			</div>
		</div>
	</nav>
	<nav class="navegacao-secundaria">
		<div class="row">
			<ul>
				<a href="#">
					<li>Cliente</li>
				</a>
				<a href="#">
					<li>Subscrição</li>
				</a>
				<a href="#">
					<li>Sinistro</li>
				</a>
				<a href="#">
					<li>Reseguro</li>
				</a>
				<a href="#">
					<li>Relatório</li>
				</a>
				<a href="#">
					<li>Parametrização</li>
				</a>
			</ul>
		</div>
	</nav>
</header>
</body>
<section class="corpo">
		<div class="form-container">
			<div class="header">
				<h3>Registro de Clientes</h3>
			</div>
			<div class="form-outer">
			    <form class="regista-cliente-form" action="#" method="POST">
				    <div class="pagina slidepaginas">	
						<div class="titulo"><h3>Dados:</h3></div>
						<div class="grid">
						    <div class="campo">
								<label>Entidade</label>
								<input class="entidade" id="entidade" type="text" list="entidade_lista"/>
					            <datalist id="entidade_lista">
					                <option value="Empresa">
					                <option value="Particular">
					            </datalist>
						    </div>
							

							<div class="campo">
								<div class="label">
								<label>Código</label>
							    </div>
							    <input type="number" name="codigo_cliente" id="codigo_cliente" value="1">
							</div>
							

					        <div class="campo nome_cliente">
								<label>Nome</label>
								<input type="text" name="nome_cliente" id="nome_cliente" placeholder="Nome do Cliente">
							</div>

							<div class="campo">
								<label>Data de Aniversário <span class="opcional">(Opcional)<span></label>
							    <input type="date" name="data_aniversario_cliente" id="data_aniversario_cliente">
							</div>
							

							<div class="campo">
								<label>Documento de identificação</label>
								<input class="docmento_identificacao_cliente" id="docmento_identificacao_cliente" type="text" list="docmento_identificacao_cliente_lista"/>
					            <datalist id="docmento_identificacao_cliente_lista">
					                <option value="Empresa">
					                <option value="Particular">
					            </datalist>
							</div>	

						</div>
						<div class="campo">
							<span class="nxtBtn">Avançar</span>
						</div>	
					</div>	
					<div class="pagina">
						<div class="titulo">
							<h3>Dados adcionais:</h3>
						</div>
						<div class="grid">
					        <div class="campo banco_cliente">
								<label>Banco  <span class="opcional">(Opcional)<span></label>
								<input type="text" name="banco_cliente" id="banco_cliente" placeholder="Nome do banco" list="banco_cliente_lista">
								<datalist id="banco_cliente_lista">
									<option value="BNA - Banco nacional de Angola">
								</datalist>
							</div>
							

							<div class="campo">
								<label>Nª do Cartão Bancário  <span class="opcional">(Opcional)<span></label>
								<input type="number" name="cartao_bancario_cliente" id="cartao_bancario_cliente" placeholder="000000000000000000">
							</div>
							


							<div class="campo">
								<label>Gerente  <span class="opcional">(Opcional)<span></label>
								<input type="text" name="gerente" id="gerente" placeholder="Nome do Gerente">
							</div>
							

							<div class="campo">
								<label>Utilizador  <span class="opcional">(Opcional)<span></label>
								<input type="text" name="utlizador" id="Utilizador" placeholder="Nome do utlilizador" list="utlilizador_lista">
								<datalist id="utlilizador_lista">
									<option value="Carlos Josemar">
								</datalist>
							</div>
						</div>
						<div class="campo btn">
							<span class="prev-1 prev">Anterior</span>
							<span class="next-1 next">Próximo</span>
						</div>
					</div>	
	               

	                <div class="pagina">	
						<div class="titulo"><h3>Residência:</h3></div>
						<div class="grid">
						    <div class="campo">
								<label>Província  <span class="opcional">(Opcional)<span></label>
								<input class="provincia" id="provincia" type="text" list="provincia_lista"/>
					            <datalist id="provincia_lista">
					                <option value="Luanda">
					            </datalist>
							</div>

							<div class="campo">
								<label>Municiipio  <span class="opcional">(Opcional)<span></label>
								<input class="municipio" id="municipio" type="text" list="municipio_lista"/>
					            <datalist id="municipio_lista">
					                <option value="Kilamba Kiaxi">
					            </datalist>
							</div>

							<div class="campo">
								<label>Endereço</label>
								<input class="endereco" id="endereco" type="text" placeholder="Bairro, Rua, nª de residência"/>			            
							</div>


						</div>
						<div class="campo btn">
							<span class="prev-2 prev">Anterior</span>
							<span class="next-2 next">Próximo</span>
						</div>
					</div>

					<div class="pagina">	
						<div class="titulo"><h3>Contacto:</h3></div>
						<div class="grid">
						    <div class="campo">
								<label>Telefone Fixo  <span class="Opcional">(Opcional)<span></label>
								<input class="telefone_fixo_cliente" id="telefone_fixo_cliente" type="number"/>
					            <datalist id="provincia_lista">
					                <option value="Luanda">
					            </datalist>
							</div>

							<div class="campo">
								<label>Telefone Móvel</label>
								<input class="telefone_movel_cliente" id="telefone_movel_cliente" type="number">
							</div>

							<div class="campo">
								<label>Email  <span class="opcional">(Opcional)<span></label>
								<input class="email_cliente" id="email_cliente" type="email" placeholder="email do cliente"/>	
							</div>

							<div class="campo">
								<label>URL  <span class="opcional">(Opcional)<span></label>
								<input class="url_website_cliente" id="url_website_cliente" type="text" placeholder="Endereço do website do Cliente"/>	
							</div>
		                    
		                    <div class="campo">
								<label>Caixa Postal  <span class="opcional">(Opcional)<span></label>
								<input class="caixa_postal_cliente" id="caixa_postal_cliente" type="text" placeholder="Caixa Postal do Cliente"/>	
							</div>

							<div class="campo">
								<label>Fax  <span class="opcional">(Opcional)<span></label>
								<input style="" class="fax_cliente" id="fax_cliente" type="number" placeholder="Endereço do website do Cliente"/>	
							</div>		
						</div>
						<div class="campo btn">
							<span class="prev-3 prev">Anterior</span>
							<span class="next-3 next">Próximo</span>
						</div>
					</div>

					<div class="pagina">	
						<div class="titulo"><h3>Outros:</h3></div>
						<div class="grid">
							<div class="campo">
								<label>Informação acdcional</label>
								<textarea name="outro" id="outro" placeholder="Alguma qualquer informação adcional"> </textarea>
							</div>
						</div>
						<div class="campo btn">
							<span class="prev-4 prev">Anterior</span>	
						    <button class="btn-salvar">Salvar</button>
						</div>	
					</div> 				      
			    </form>
		    </div>
		</div>
	
</section>