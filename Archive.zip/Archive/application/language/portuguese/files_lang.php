<?php
//////////Modules/////////////////////// tabs name
$lang['home'] 	  = 'Home';
$lang['FileDesc'] 	  = 'FileDesc';
$lang['image'] 	  = 'Image';
$lang['files'] 	  = 'files';
$lang['CreatedAt'] 	  = 'CreatedAt';
$lang['options'] 	  = 'Options';
$lang['sound'] 	  = 'Sounds';
$lang['video'] 	  = 'Videos';
$lang['pages']    = "Extera pages";
$lang['news']     = "News";
$lang['photos']   ="Photo galary";
$lang['articles'] ="Articles";
$lang['navigation'] ="Navigation";
$lang['contactus'] ="Contact us";
$lang['visitors'] ="Visitors";
$lang['book'] ="E-book Library";
$lang['public_trips'] = "Public trips";