<style>
	#infoMessage{
		color: red;
	}
</style>
<header class="main-header">
	<nav>
		<div class="row">
			<div class="logo-div">
				<img src="imagens/logo.png" alt="logotipo">
			</div>
			<div class="nav-direita">
				<ul class="main-nav js--main-nav">
					<a href="#" class="activo">
						<li>Pagina Incial</li>
					</a>
					<a href="#">
						<li>Sobre</li>
					</a>
				</ul>
				<!--Menú da versão mobile-->	<a class="mobile-nav js--mobile-nav"><i class="ion-navicon-round"></i></a>
			</div>
		</div>
	</nav>
	<!--Waves(onda) que está no background-->
	<svg class="waves-do-header" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
		<path fill="#0099ff" fill-opacity="1" d="M0,256L34.3,256C68.6,256,137,256,206,245.3C274.3,235,343,213,411,213.3C480,213,549,235,617,224C685.7,213,754,171,823,133.3C891.4,96,960,64,1029,48C1097.1,32,1166,32,1234,42.7C1302.9,53,1371,75,1406,85.3L1440,96L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path>
	</svg>
	<div class="row">
		<!--Caixa de mensagem que está no background-->
		<div class="hero">
			<div class="hero-mensagem">
				<h1>Mantenha-se seguro com a <span class="hero-enfase">SSPLATFORM</span></h1>
				<P>Gerencie uma grande quantidade de clientes de uma maneira fácil e rápida. Desfute de recursos bem efecientes da nossa plataforma</P>
				<br>
				<p class="faca-login">Faça Login para começar <i class="ion-arrow-right-c"></i></p>
			</div>
		</div>
	</div>
	<!--Formulário de Login-->
	<div class="row center">
		<div class="form-container">
			<?php echo form_open("conta/login");?>
			<form class="form-login">
				<header>	<i class="form-login-header-icon ion-android-person"></i>
					<h3>Login</h3>
					<p>Faça login em sua conta</p>
					<br>
					<p><div id="infoMessage"><?php echo $message;?></div></p>
				</header>
				<div class="campo">
					<label>Email de usuário</label>
					<p>
						<i class="ion-android-person"></i>
						<?php echo form_input($identity,'','type="text" name="nome_de_usuario" placeholder="seu email de usuário"');?>
					</p>
				</div>
				<div class="campo">
					<label>Senha</label>
					<p><i class="ion-locked"></i>
						<?php echo form_input($password,'','type="password" name="senha"');?>
					</p>
				</div>
				<div class="campo-btn">
					<!--
					<?php echo form_submit('submit', lang('login_submit_btn'),'class="btn-login"');?>
					-->
					<button type="submit" class="btn-login">Login</button>
				</div>
			</form>
			<?php echo form_close();?>
		</div>
	</div>
	<!--Footer-->
	<footer>
		<div class="row">	<span>superseguros @copyright</span>
		</div>
	</footer>
</header>