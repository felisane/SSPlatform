</body>
    <!--Bibiotecas javascrit[JQUERY]-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
    <script src="<?php echo base_url(); ?>assets/resources/vendors/js/jquery.waypoints.min.js"></script>

     <!--o ficheiro que contém o código javascript-->
    <script src="<?php echo base_url(); ?>assets/js/script.js"></script>
</html>